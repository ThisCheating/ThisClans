package com.thischeating.thisclans;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ClanCommand implements CommandExecutor, TabCompleter {
    private final ThisClans plugin;
    private final ClanManager clans;
    private final WaypointManager waypoints;

    public ClanCommand(ThisClans plugin, ClanManager clans, WaypointManager waypoints) {
        this.plugin = plugin;
        this.clans = clans;
        this.waypoints = waypoints;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> create(sender, args);
            case "invite" -> invite(sender, args);
            case "accept" -> accept(sender);
            case "kick" -> kick(sender, args);
            case "leave" -> leave(sender);
            case "disband" -> disband(sender, args);
            case "sethome" -> setHome(sender);
            case "home" -> home(sender);
            case "rally" -> rally(sender);
            case "setspawn" -> setSpawn(sender, args);
            case "reload" -> reload(sender);
            default -> help(sender);
        }
        return true;
    }

    private void send(CommandSender target, String message) {
        plugin.send(target, message);
    }

    private void create(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 2) {
            send(player, "§c/clan create <nombre>");
            return;
        }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_]{3,16}")) {
            send(player, "§cNombre inválido. Usa 3-16 caracteres: A-Z, 0-9 o _.");
            return;
        }
        if (clans.createClan(name, player.getUniqueId())) {
            send(player, "§aClan creado: §f" + name);
        } else {
            send(player, "§cEse nombre ya existe o ya tienes un clan.");
        }
    }

    private void invite(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "§cSolo el líder puede invitar.");
            return;
        }
        if (args.length < 2) {
            send(player, "§c/clan invite <jugador>");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            send(player, "§cJugador no encontrado.");
            return;
        }
        if (clans.hasClan(target.getUniqueId())) {
            send(player, "§cEse jugador ya tiene clan.");
            return;
        }

        PendingInvite.put(target.getUniqueId(), clan.getName());
        send(player, "§aInvitación enviada a §f" + target.getName());
        send(target, "§eHas sido invitado al clan §f" + clan.getName() + "§e.");
        send(target, "§7Usa §f/clan accept §7para aceptar (expira en "
                + PendingInvite.ttlSeconds() + " segundos).");
    }

    private void accept(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        if (clans.hasClan(player.getUniqueId())) {
            send(player, "§cYa tienes clan.");
            return;
        }

        String clanName = PendingInvite.get(player.getUniqueId());
        if (clanName == null) {
            send(player, "§cNo tienes invitaciones pendientes o ya expiraron.");
            return;
        }

        Clan clan = clans.getClan(clanName);
        if (clan == null) {
            PendingInvite.remove(player.getUniqueId());
            send(player, "§cEse clan ya no existe.");
            return;
        }

        if (clans.addMember(clan, player.getUniqueId())) {
            PendingInvite.remove(player.getUniqueId());
            send(player, "§aTe uniste a §f" + clan.getName() + "§a.");
            waypoints.sendHome(player);
        } else {
            send(player, "§cNo se pudo unir al clan.");
        }
    }

    private void kick(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "§cSolo el líder puede expulsar.");
            return;
        }
        if (args.length < 2) {
            send(player, "§c/clan kick <jugador>");
            return;
        }

        UUID targetId = findMemberByName(clan, args[1]);
        if (targetId == null) {
            send(player, "§cEse jugador no pertenece al clan.");
            return;
        }
        if (targetId.equals(clan.getOwner())) {
            send(player, "§cNo puedes expulsarte a ti mismo. Usa §f/clan disband§c para disolver el clan.");
            return;
        }

        if (clans.removeMember(clan, targetId)) {
            Player target = Bukkit.getPlayer(targetId);
            if (target != null) {
                send(target, "§cHas sido expulsado del clan.");
                waypoints.removeClanWaypoints(target);
            }
            send(player, "§aJugador expulsado.");
        } else {
            send(player, "§cNo se pudo expulsar al jugador.");
        }
    }

    private void leave(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "§cNo tienes clan.");
            return;
        }
        if (clan.getOwner().equals(player.getUniqueId())) {
            send(player, "§cEres el líder. Usa §f/clan disband confirm§c para disolver el clan.");
            return;
        }

        if (clans.removeMember(clan, player.getUniqueId())) {
            waypoints.removeClanWaypoints(player);
            send(player, "§aSaliste del clan §f" + clan.getName() + "§a.");
            for (UUID uuid : clan.getMembers()) {
                Player member = Bukkit.getPlayer(uuid);
                if (member != null && member.isOnline()) {
                    send(member, "§e" + player.getName() + " salió del clan.");
                }
            }
        } else {
            send(player, "§cNo se pudo salir del clan.");
        }
    }

    private void disband(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "§cSolo el líder puede disolver el clan.");
            return;
        }
        if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
            send(player, "§eEsto borra el clan §f" + clan.getName()
                    + "§e para siempre. Escribe §f/clan disband confirm §epara confirmar.");
            return;
        }

        List<UUID> members = new ArrayList<>(clan.getMembers());
        waypoints.cancelRally(clan);

        if (clans.disbandClan(clan)) {
            for (UUID uuid : members) {
                Player member = Bukkit.getPlayer(uuid);
                if (member != null && member.isOnline()) {
                    waypoints.removeClanWaypoints(member);
                    send(member, "§cEl clan §f" + clan.getName() + "§c fue disuelto.");
                }
            }
        } else {
            send(player, "§cNo se pudo disolver el clan.");
        }
    }

    private void setHome(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "§cSolo el líder puede cambiar la base.");
            return;
        }

        Location home = player.getLocation().clone();
        clan.setHome(home);
        clans.save();

        for (UUID uuid : clan.getMembers()) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                waypoints.sendHome(member);
            }
        }
        send(player, "§aBase del clan actualizada.");
    }

    private void home(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());

        if (clan == null || !clan.hasHome()) {
            send(player, "§cTu clan no tiene base.");
            return;
        }

        Location home = clan.getHome();
        if (home == null) {
            send(player, "§cEl mundo de la base no está cargado en este momento.");
            return;
        }

        player.teleportAsync(home);
        send(player, "§aTeletransportándote a la base...");
    }

    private void rally(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        if (clans.getClan(player.getUniqueId()) == null) {
            send(player, "§cNo tienes clan.");
            return;
        }

        waypoints.sendRally(player);
        long seconds = Math.max(1L,
                plugin.getConfig().getLong("settings.rally-duration-seconds", 60L));
        send(player, "§6Rally activado durante §f" + seconds + " segundos§6.");
    }

    private void setSpawn(CommandSender sender, String[] args) {
        if (!sender.hasPermission("thisclans.admin")) {
            send(sender, "§cSin permisos.");
            return;
        }
        if (args.length < 4) {
            send(sender, "§c/clan setspawn <x> <y> <z>");
            return;
        }

        double x;
        double y;
        double z;
        try {
            x = Double.parseDouble(args[1]);
            y = Double.parseDouble(args[2]);
            z = Double.parseDouble(args[3]);
        } catch (NumberFormatException e) {
            send(sender, "§cLas coordenadas deben ser números.");
            return;
        }

        final double limit = 30_000_000D;
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)
                || Math.abs(x) > limit || Math.abs(y) > 1_000_000D || Math.abs(z) > limit) {
            send(sender, "§cCoordenadas fuera de rango.");
            return;
        }

        String world;
        if (sender instanceof Player player) {
            world = player.getWorld().getName();
        } else {
            world = plugin.getConfig().getString("spawn.world", "world");
        }

        plugin.getConfig().set("spawn.world", world);
        plugin.getConfig().set("spawn.x", x);
        plugin.getConfig().set("spawn.y", y);
        plugin.getConfig().set("spawn.z", z);
        plugin.saveConfig();

        for (Player online : Bukkit.getOnlinePlayers()) {
            waypoints.sendSpawn(online);
        }
        send(sender, "§aWaypoint global de Spawn actualizado.");
    }

    private void reload(CommandSender sender) {
        if (!sender.hasPermission("thisclans.admin")) {
            send(sender, "§cSin permisos.");
            return;
        }
        plugin.reloadConfig();
        send(sender, "§aConfiguración recargada.");
    }

    private UUID findMemberByName(Clan clan, String name) {
        for (UUID uuid : clan.getMembers()) {
            String memberName = Bukkit.getOfflinePlayer(uuid).getName();
            if (memberName != null && memberName.equalsIgnoreCase(name)) {
                return uuid;
            }
        }
        return null;
    }

    private void help(CommandSender sender) {
        sender.sendMessage("§6§lThisClans");
        sender.sendMessage("§e/clan create <nombre>");
        sender.sendMessage("§e/clan invite <jugador>");
        sender.sendMessage("§e/clan accept");
        sender.sendMessage("§e/clan kick <jugador>");
        sender.sendMessage("§e/clan leave");
        sender.sendMessage("§e/clan disband confirm");
        sender.sendMessage("§e/clan sethome");
        sender.sendMessage("§e/clan home");
        sender.sendMessage("§e/clan rally");
        if (sender.hasPermission("thisclans.admin")) {
            sender.sendMessage("§e/clan setspawn <x> <y> <z>");
            sender.sendMessage("§e/clan reload");
        }
    }

    @Override
    public List<String> onTabComplete(
            CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> values = new ArrayList<>(List.of(
                    "create", "invite", "accept", "kick", "leave", "disband",
                    "sethome", "home", "rally"
            ));
            if (sender.hasPermission("thisclans.admin")) {
                values.add("setspawn");
                values.add("reload");
            }
            return values.stream()
                    .filter(v -> v.startsWith(args[0].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("invite")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("kick")
                && sender instanceof Player player) {
            Clan clan = clans.getClan(player.getUniqueId());
            if (clan == null) return List.of();
            List<String> names = new ArrayList<>();
            for (UUID uuid : clan.getMembers()) {
                String name = Bukkit.getOfflinePlayer(uuid).getName();
                if (name != null && !uuid.equals(clan.getOwner())
                        && name.toLowerCase().startsWith(args[1].toLowerCase())) {
                    names.add(name);
                }
            }
            return names;
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("disband")
                && "confirm".startsWith(args[1].toLowerCase())) {
            return List.of("confirm");
        }

        return List.of();
    }
}
