package com.thischeating.thisclans;

import com.lunarclient.apollo.Apollo;
import com.lunarclient.apollo.common.location.ApolloBlockLocation;
import com.lunarclient.apollo.module.waypoint.Waypoint;
import com.lunarclient.apollo.module.waypoint.WaypointModule;
import com.lunarclient.apollo.player.ApolloPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class WaypointManager {
    // Apollo identifica cada waypoint por su nombre, asi que el id es el nombre.
    public static final String SPAWN_ID = "Spawn";
    public static final String HOME_ID = "Clan Base";
    public static final String RALLY_ID = "Clan Rally";

    private final ThisClans plugin;
    private final WaypointModule waypointModule;
    // Un rally activo por clan (clave = nombre del clan en minusculas).
    private final Map<String, BukkitTask> rallyTasks = new HashMap<>();

    public WaypointManager(ThisClans plugin) {
        this.plugin = plugin;
        this.waypointModule =
                Apollo.getModuleManager().getModule(WaypointModule.class);
    }

    public void sendSpawn(Player player) {
        Location location = getSpawnLocation();
        if (location != null) {
            display(player, SPAWN_ID, location, Color.GREEN);
        }
    }

    public void sendHome(Player player) {
        Clan clan = plugin.getClanManager().getClan(player.getUniqueId());
        Location home = clan == null ? null : clan.getHome();
        if (home == null) {
            remove(player, HOME_ID);
            return;
        }
        display(player, HOME_ID, home, Color.CYAN);
    }

    public void sendRally(Player source) {
        Clan clan = plugin.getClanManager().getClan(source.getUniqueId());
        if (clan == null) return;

        Location location = source.getLocation().clone();
        String key = rallyKey(clan);
        cancelRally(clan);

        for (UUID uuid : new ArrayList<>(clan.getMembers())) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                display(member, RALLY_ID, location, Color.ORANGE);
            }
        }

        long seconds = Math.max(1L,
                plugin.getConfig().getLong("settings.rally-duration-seconds", 60L));

        BukkitTask task = Bukkit.getScheduler().runTaskLater(
                plugin,
                () -> {
                    rallyTasks.remove(key);
                    for (UUID uuid : new ArrayList<>(clan.getMembers())) {
                        Player member = Bukkit.getPlayer(uuid);
                        if (member != null && member.isOnline()) {
                            remove(member, RALLY_ID);
                        }
                    }
                },
                seconds * 20L
        );

        rallyTasks.put(key, task);
    }

    public void refreshPlayer(Player player) {
        sendSpawn(player);
        sendHome(player);
    }

    public void clear(Player player) {
        remove(player, SPAWN_ID);
        remove(player, HOME_ID);
        remove(player, RALLY_ID);
    }

    /** Quita los waypoints que dependen del clan (base y rally), no el spawn. */
    public void removeClanWaypoints(Player player) {
        remove(player, HOME_ID);
        remove(player, RALLY_ID);
    }

    public void cancelRally(Clan clan) {
        BukkitTask old = rallyTasks.remove(rallyKey(clan));
        if (old != null) old.cancel();
    }

    public void shutdown() {
        for (BukkitTask task : rallyTasks.values()) {
            task.cancel();
        }
        rallyTasks.clear();
    }

    private String rallyKey(Clan clan) {
        return clan.getName().toLowerCase(Locale.ROOT);
    }

    private void display(Player player, String id, Location location, Color color) {
        Optional<ApolloPlayer> apolloPlayer =
                Apollo.getPlayerManager().getPlayer(player.getUniqueId());

        if (apolloPlayer.isEmpty()) return;
        if (location.getWorld() == null) return;

        ApolloBlockLocation blockLocation = ApolloBlockLocation.builder()
                .world(location.getWorld().getName())
                .x(location.getBlockX())
                .y(location.getBlockY())
                .z(location.getBlockZ())
                .build();

        Waypoint waypoint = Waypoint.builder()
                .name(id)
                .location(blockLocation)
                .color(color)
                .preventRemoval(false)
                .hidden(false)
                .build();

        waypointModule.displayWaypoint(apolloPlayer.get(), waypoint);
    }

    private void remove(Player player, String id) {
        Optional<ApolloPlayer> apolloPlayer =
                Apollo.getPlayerManager().getPlayer(player.getUniqueId());

        apolloPlayer.ifPresent(p -> waypointModule.removeWaypoint(p, id));
    }

    private Location getSpawnLocation() {
        String worldName = plugin.getConfig().getString("spawn.world");
        if (worldName == null) return null;

        org.bukkit.World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        return new Location(
                world,
                plugin.getConfig().getDouble("spawn.x"),
                plugin.getConfig().getDouble("spawn.y"),
                plugin.getConfig().getDouble("spawn.z")
        );
    }
}
