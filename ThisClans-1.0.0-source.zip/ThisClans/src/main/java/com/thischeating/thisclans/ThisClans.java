package com.thischeating.thisclans;

import org.bukkit.plugin.java.JavaPlugin;

public final class ThisClans extends JavaPlugin {

    private ClanManager clanManager;
    private WaypointManager waypointManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        clanManager = new ClanManager(this);
        clanManager.load();

        waypointManager = new WaypointManager(this);

        ClanCommand command = new ClanCommand(this, clanManager, waypointManager);
        if (getCommand("clan") != null) {
            getCommand("clan").setExecutor(command);
            getCommand("clan").setTabCompleter(command);
        }

        getServer().getPluginManager().registerEvents(
                new PlayerListener(this, waypointManager), this);

        new ApolloListener(this, waypointManager);

        long minutes = Math.max(1L, getConfig().getLong("settings.autosave-minutes", 5L));
        long ticks = minutes * 60L * 20L;

        getServer().getScheduler().runTaskTimer(
                this,
                clanManager::save,
                ticks,
                ticks
        );

        getLogger().info("ThisClans enabled.");
    }

    @Override
    public void onDisable() {
        if (clanManager != null) {
            clanManager.save();
        }
    }

    public ClanManager getClanManager() {
        return clanManager;
    }

    public WaypointManager getWaypointManager() {
        return waypointManager;
    }
}
