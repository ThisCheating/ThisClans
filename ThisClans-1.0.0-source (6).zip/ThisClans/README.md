# ThisClans

Plugin ligero de clanes para Paper 1.21.11 con integración de waypoints de Lunar Client Apollo.

## Dependencias del servidor

Instala Apollo externamente en el servidor.

ThisClans NO incluye Apollo dentro de su JAR.

## Compilar

Requisitos:
- Java 21
- Maven

Ejecuta:

```bash
mvn clean package
```

JAR generado:

```text
target/ThisClans-1.0.0.jar
```

Copia el JAR a:

```text
plugins/
```

y coloca Apollo externamente en `plugins/`.

## Comandos

/clan create <nombre>
/clan invite <jugador>
/clan accept
/clan kick <jugador>
/clan leave
/clan disband confirm
/clan sethome
/clan home
/clan rally
/clan setspawn <x> <y> <z>

## Waypoints

- Spawn global para jugadores Lunar Client.
- Base del clan para miembros Lunar Client.
- Rally durante 60 segundos.
- /clan sethome actualiza el waypoint de los miembros conectados.

Los waypoints iniciales se envían en ApolloRegisterPlayerEvent, no en PlayerJoinEvent.

## Persistencia

Los clanes se guardan en plugins/ThisClans/clans.yml.

## Configuración

Archivos en `plugins/ThisClans/`:

- `config.yml`: spawn, duración y radio del rally, colores de los waypoints (hex) y autoguardado.
- `messages.yml`: **todos los textos** (prefijo, mensajes, ayuda y nombres de los waypoints). Usa `&` para colores y placeholders como `{player}`, `{clan}`, `{seconds}`, `{x}`, `{y}`, `{z}`.

Aplica los cambios con `/clan reload` (permiso `thisclans.admin`). Si falta una clave en tu `messages.yml`, el plugin usa el texto por defecto.

## Rally

Cada vez que un miembro usa `/clan rally`, el rally del clan se mueve a su posición: se reemplaza el waypoint, se redibuja el círculo y el tiempo vuelve a empezar. El resto del clan recibe un aviso con las coordenadas.

## Si no se ven los waypoints

1. Usa Lunar Client y el mod **Waypoints** debe estar activado.
2. En `plugins/Apollo-Bukkit/config.yml` (el de Apollo, no el de ThisClans) el módulo `waypoint` debe tener `enable: true` y `server-handles-waypoints: true`. Reinicia o usa `/apollo reload`.
3. Pon `settings.debug: true` en el config de ThisClans, haz `/clan reload` y revisa la consola.
