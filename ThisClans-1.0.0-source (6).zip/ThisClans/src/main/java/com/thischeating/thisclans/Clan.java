package com.thischeating.thisclans;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Clan {
    private final String name;
    private final UUID owner;
    private final Set<UUID> members = new HashSet<>();

    // La base se guarda en bruto (nombre de mundo + coordenadas) para no
    // perderla si el mundo todavia no esta cargado al iniciar el servidor.
    private String homeWorld;
    private double homeX;
    private double homeY;
    private double homeZ;
    private float homeYaw;
    private float homePitch;

    public Clan(String name, UUID owner) {
        this.name = name;
        this.owner = owner;
        members.add(owner);
    }

    public String getName() { return name; }
    public UUID getOwner() { return owner; }
    public Set<UUID> getMembers() { return members; }

    public boolean isMember(UUID uuid) {
        return members.contains(uuid);
    }

    public void addMember(UUID uuid) {
        members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public boolean hasHome() {
        return homeWorld != null;
    }

    /** Devuelve la base, o null si no existe o su mundo no esta cargado. */
    public Location getHome() {
        if (homeWorld == null) return null;
        World world = Bukkit.getWorld(homeWorld);
        if (world == null) return null;
        return new Location(world, homeX, homeY, homeZ, homeYaw, homePitch);
    }

    public void setHome(Location location) {
        if (location == null || location.getWorld() == null) {
            homeWorld = null;
            return;
        }
        setRawHome(
                location.getWorld().getName(),
                location.getX(), location.getY(), location.getZ(),
                location.getYaw(), location.getPitch()
        );
    }

    public void setRawHome(String world, double x, double y, double z, float yaw, float pitch) {
        this.homeWorld = world;
        this.homeX = x;
        this.homeY = y;
        this.homeZ = z;
        this.homeYaw = yaw;
        this.homePitch = pitch;
    }

    public String getHomeWorld() { return homeWorld; }
    public double getHomeX() { return homeX; }
    public double getHomeY() { return homeY; }
    public double getHomeZ() { return homeZ; }
    public float getHomeYaw() { return homeYaw; }
    public float getHomePitch() { return homePitch; }
}
