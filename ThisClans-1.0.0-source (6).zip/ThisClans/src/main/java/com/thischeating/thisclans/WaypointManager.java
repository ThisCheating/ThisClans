package com.thischeating.thisclans;

import com.lunarclient.apollo.Apollo;
import com.lunarclient.apollo.common.location.ApolloBlockLocation;
import com.lunarclient.apollo.module.waypoint.Waypoint;
import com.lunarclient.apollo.module.waypoint.WaypointModule;
import com.lunarclient.apollo.player.ApolloPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class WaypointManager {
    private static final long RALLY_TICK_INTERVAL = 10L;

    private final ThisClans plugin;
    private final WaypointModule waypointModule;
    // Un rally activo por clan (clave = nombre del clan en minusculas).
    private final Map<String, BukkitTask> rallyTasks = new HashMap<>();

    public WaypointManager(ThisClans plugin) {
        this.plugin = plugin;
        this.waypointModule =
                Apollo.getModuleManager().getModule(WaypointModule.class);
    }

    // Apollo identifica cada waypoint por su nombre, asi que el nombre es el id.
    // Los nombres se leen de messages.yml (waypoints.spawn / home / rally).
    private String spawnName() {
        return plugin.getMessages().plain("waypoints.spawn");
    }

    private String homeName() {
        return plugin.getMessages().plain("waypoints.home");
    }

    private String rallyName() {
        return plugin.getMessages().plain("waypoints.rally");
    }

    private Color readColor(String path, Color fallback) {
        String raw = plugin.getConfig().getString(path);
        if (raw == null) return fallback;
        try {
            return Color.decode(raw.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    public void sendSpawn(Player player) {
        Location location = getSpawnLocation();
        if (location != null) {
            display(player, spawnName(), location,
                    readColor("waypoints.spawn-color", Color.GREEN), true);
        }
    }

    public void sendHome(Player player) {
        Clan clan = plugin.getClanManager().getClan(player.getUniqueId());
        Location home = clan == null ? null : clan.getHome();
        if (home == null) {
            remove(player, homeName());
            return;
        }
        display(player, homeName(), home,
                readColor("waypoints.home-color", Color.CYAN), true);
    }

    /**
     * Activa el rally del clan en la posicion de {@code source}. Si ya habia un rally
     * activo, lo reemplaza: el waypoint y el circulo se mueven a la nueva posicion.
     */
    public void sendRally(Player source) {
        Clan clan = plugin.getClanManager().getClan(source.getUniqueId());
        if (clan == null) return;

        Location location = source.getLocation().clone();
        String key = rallyKey(clan);
        cancelRally(clan);

        Color rallyColor = readColor("waypoints.rally-color", Color.GREEN);

        for (UUID uuid : new ArrayList<>(clan.getMembers())) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                // Se quita el waypoint anterior para que no queden dos con el mismo nombre.
                remove(member, rallyName());
                display(member, rallyName(), location, rallyColor, false);
            }
        }

        long seconds = getRallySeconds();
        double radius = Math.min(30.0D, Math.max(1.0D,
                plugin.getConfig().getDouble("settings.rally-radius", 5.0D)));
        boolean ring = plugin.getConfig().getBoolean("settings.rally-ring", true);

        final long totalTicks = seconds * 20L;
        final long[] elapsed = {0L};

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(
                plugin,
                () -> {
                    if (elapsed[0] >= totalTicks) {
                        cancelRally(clan);
                        for (UUID uuid : new ArrayList<>(clan.getMembers())) {
                            Player member = Bukkit.getPlayer(uuid);
                            if (member != null && member.isOnline()) {
                                remove(member, rallyName());
                            }
                        }
                        return;
                    }
                    if (ring) {
                        drawRing(clan, location, radius, rallyColor);
                    }
                    elapsed[0] += RALLY_TICK_INTERVAL;
                },
                0L,
                RALLY_TICK_INTERVAL
        );

        rallyTasks.put(key, task);
    }

    public long getRallySeconds() {
        return Math.max(1L,
                plugin.getConfig().getLong("settings.rally-duration-seconds", 60L));
    }

    /** Dibuja un circulo de particulas en el suelo, solo para miembros del clan. */
    private void drawRing(Clan clan, Location center, double radius, Color color) {
        World world = center.getWorld();
        if (world == null) return;

        Particle.DustOptions dust = new Particle.DustOptions(
                org.bukkit.Color.fromRGB(color.getRed(), color.getGreen(), color.getBlue()),
                1.6f);
        int points = Math.max(24, (int) Math.round(radius * 10.0D));

        for (UUID uuid : new ArrayList<>(clan.getMembers())) {
            Player member = Bukkit.getPlayer(uuid);
            if (member == null || !member.isOnline()) continue;
            if (!world.equals(member.getWorld())) continue;

            for (int i = 0; i < points; i++) {
                double angle = 2.0D * Math.PI * i / points;
                double x = center.getX() + radius * Math.cos(angle);
                double z = center.getZ() + radius * Math.sin(angle);
                member.spawnParticle(Particle.DUST, x, center.getY() + 0.15D, z,
                        1, 0.0D, 0.0D, 0.0D, 0.0D, dust);
            }
        }
    }

    public void refreshPlayer(Player player) {
        sendSpawn(player);
        sendHome(player);
    }

    public void clear(Player player) {
        remove(player, spawnName());
        remove(player, homeName());
        remove(player, rallyName());
    }

    /** Quita los waypoints que dependen del clan (base y rally), no el spawn. */
    public void removeClanWaypoints(Player player) {
        remove(player, homeName());
        remove(player, rallyName());
    }

    public void cancelRally(Clan clan) {
        BukkitTask old = rallyTasks.remove(rallyKey(clan));
        if (old != null) old.cancel();
    }

    public void shutdown() {
        for (BukkitTask task : rallyTasks.values()) {
            task.cancel();
        }
        rallyTasks.clear();
    }

    private String rallyKey(Clan clan) {
        return clan.getName().toLowerCase(Locale.ROOT);
    }

    private void display(Player player, String id, Location location, Color color,
                         boolean highlightBlock) {
        Optional<ApolloPlayer> apolloPlayer =
                Apollo.getPlayerManager().getPlayer(player.getUniqueId());

        if (apolloPlayer.isEmpty()) {
            debug("No se envió '" + id + "' a " + player.getName()
                    + ": no está registrado en Apollo (¿usa Lunar Client?).");
            return;
        }
        if (location.getWorld() == null) return;

        ApolloBlockLocation blockLocation = ApolloBlockLocation.builder()
                .world(location.getWorld().getName())
                .x(location.getBlockX())
                .y(location.getBlockY())
                .z(location.getBlockZ())
                .build();

        Waypoint waypoint = Waypoint.builder()
                .name(id)
                .location(blockLocation)
                .color(color)
                .preventRemoval(false)
                .hidden(false)
                .highlightBlock(highlightBlock)
                .build();

        try {
            waypointModule.displayWaypoint(apolloPlayer.get(), waypoint);
            debug("Waypoint '" + id + "' enviado a " + player.getName());
        } catch (Exception e) {
            plugin.getLogger().warning("No se pudo enviar el waypoint '" + id
                    + "' a " + player.getName() + ": " + e);
        }
    }

    public void debug(String message) {
        if (plugin.getConfig().getBoolean("settings.debug", false)) {
            plugin.getLogger().info("[debug] " + message);
        }
    }

    private void remove(Player player, String id) {
        Optional<ApolloPlayer> apolloPlayer =
                Apollo.getPlayerManager().getPlayer(player.getUniqueId());

        apolloPlayer.ifPresent(p -> waypointModule.removeWaypoint(p, id));
    }

    private Location getSpawnLocation() {
        String worldName = plugin.getConfig().getString("spawn.world");
        if (worldName == null) return null;

        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        return new Location(
                world,
                plugin.getConfig().getDouble("spawn.x"),
                plugin.getConfig().getDouble("spawn.y"),
                plugin.getConfig().getDouble("spawn.z")
        );
    }
}
