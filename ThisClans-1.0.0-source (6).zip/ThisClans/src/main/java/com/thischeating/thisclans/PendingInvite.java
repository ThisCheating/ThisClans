package com.thischeating.thisclans;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PendingInvite {
    private static final long TTL_MILLIS = 120_000L;

    private record Invite(String clan, long expiresAt) {}

    private static final Map<UUID, Invite> INVITES = new ConcurrentHashMap<>();

    private PendingInvite() {}

    public static void put(UUID player, String clan) {
        INVITES.put(player, new Invite(clan, System.currentTimeMillis() + TTL_MILLIS));
    }

    /** Devuelve el clan que invito al jugador, o null si no hay invitacion o ya expiro. */
    public static String get(UUID player) {
        Invite invite = INVITES.get(player);
        if (invite == null) return null;
        if (invite.expiresAt() < System.currentTimeMillis()) {
            INVITES.remove(player);
            return null;
        }
        return invite.clan();
    }

    public static void remove(UUID player) {
        INVITES.remove(player);
    }

    public static long ttlSeconds() {
        return TTL_MILLIS / 1000L;
    }
}
