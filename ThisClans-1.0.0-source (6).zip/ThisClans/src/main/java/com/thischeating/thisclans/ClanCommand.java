package com.thischeating.thisclans;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ClanCommand implements CommandExecutor, TabCompleter {
    private final ThisClans plugin;
    private final ClanManager clans;
    private final WaypointManager waypoints;

    public ClanCommand(ThisClans plugin, ClanManager clans, WaypointManager waypoints) {
        this.plugin = plugin;
        this.clans = clans;
        this.waypoints = waypoints;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> create(sender, args);
            case "invite" -> invite(sender, args);
            case "accept" -> accept(sender);
            case "kick" -> kick(sender, args);
            case "leave" -> leave(sender);
            case "disband" -> disband(sender, args);
            case "sethome" -> setHome(sender);
            case "home" -> home(sender);
            case "rally" -> rally(sender);
            case "setspawn" -> setSpawn(sender, args);
            case "reload" -> reload(sender);
            default -> help(sender);
        }
        return true;
    }

    private void send(CommandSender target, String key, String... pairs) {
        plugin.getMessages().send(target, key, pairs);
    }

    private void create(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 2) {
            send(player, "usage-create");
            return;
        }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_]{3,16}")) {
            send(player, "invalid-name");
            return;
        }
        if (clans.createClan(name, player.getUniqueId())) {
            send(player, "clan-created", "clan", name);
        } else {
            send(player, "create-failed");
        }
    }

    private void invite(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "no-clan");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "only-leader-invite");
            return;
        }
        if (args.length < 2) {
            send(player, "usage-invite");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            send(player, "player-not-found");
            return;
        }
        if (clans.hasClan(target.getUniqueId())) {
            send(player, "target-has-clan");
            return;
        }

        PendingInvite.put(target.getUniqueId(), clan.getName());
        send(player, "invite-sent", "player", target.getName());
        send(target, "invite-received", "clan", clan.getName());
        send(target, "invite-received-hint", "seconds",
                String.valueOf(PendingInvite.ttlSeconds()));
    }

    private void accept(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        if (clans.hasClan(player.getUniqueId())) {
            send(player, "already-in-clan");
            return;
        }

        String clanName = PendingInvite.get(player.getUniqueId());
        if (clanName == null) {
            send(player, "no-invite");
            return;
        }

        Clan clan = clans.getClan(clanName);
        if (clan == null) {
            PendingInvite.remove(player.getUniqueId());
            send(player, "clan-gone");
            return;
        }

        if (clans.addMember(clan, player.getUniqueId())) {
            PendingInvite.remove(player.getUniqueId());
            send(player, "joined", "clan", clan.getName());
            waypoints.sendHome(player);
        } else {
            send(player, "join-failed");
        }
    }

    private void kick(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "no-clan");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "only-leader-kick");
            return;
        }
        if (args.length < 2) {
            send(player, "usage-kick");
            return;
        }

        UUID targetId = findMemberByName(clan, args[1]);
        if (targetId == null) {
            send(player, "not-a-member");
            return;
        }
        if (targetId.equals(clan.getOwner())) {
            send(player, "cannot-kick-self");
            return;
        }

        if (clans.removeMember(clan, targetId)) {
            Player target = Bukkit.getPlayer(targetId);
            if (target != null) {
                send(target, "kicked-target");
                waypoints.removeClanWaypoints(target);
            }
            send(player, "kicked");
        } else {
            send(player, "kick-failed");
        }
    }

    private void leave(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "no-clan");
            return;
        }
        if (clan.getOwner().equals(player.getUniqueId())) {
            send(player, "leader-cannot-leave");
            return;
        }

        if (clans.removeMember(clan, player.getUniqueId())) {
            waypoints.removeClanWaypoints(player);
            send(player, "left", "clan", clan.getName());
            for (UUID uuid : clan.getMembers()) {
                Player member = Bukkit.getPlayer(uuid);
                if (member != null && member.isOnline()) {
                    send(member, "member-left", "player", player.getName());
                }
            }
        } else {
            send(player, "leave-failed");
        }
    }

    private void disband(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "no-clan");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "only-leader-disband");
            return;
        }
        if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
            send(player, "disband-confirm", "clan", clan.getName());
            return;
        }

        List<UUID> members = new ArrayList<>(clan.getMembers());
        waypoints.cancelRally(clan);

        if (clans.disbandClan(clan)) {
            for (UUID uuid : members) {
                Player member = Bukkit.getPlayer(uuid);
                if (member != null && member.isOnline()) {
                    waypoints.removeClanWaypoints(member);
                    send(member, "disbanded", "clan", clan.getName());
                }
            }
        } else {
            send(player, "disband-failed");
        }
    }

    private void setHome(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "no-clan");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            send(player, "only-leader-sethome");
            return;
        }

        Location home = player.getLocation().clone();
        clan.setHome(home);
        clans.save();

        for (UUID uuid : clan.getMembers()) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                waypoints.sendHome(member);
            }
        }
        send(player, "home-updated");
    }

    private void home(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());

        if (clan == null || !clan.hasHome()) {
            send(player, "no-home");
            return;
        }

        Location home = clan.getHome();
        if (home == null) {
            send(player, "home-world-unloaded");
            return;
        }

        player.teleportAsync(home);
        send(player, "teleporting");
    }

    private void rally(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            send(player, "no-clan");
            return;
        }

        // Si ya habia un rally, se reemplaza y se mueve a la posicion actual.
        waypoints.sendRally(player);

        Location loc = player.getLocation();
        String[] data = {
                "player", player.getName(),
                "seconds", String.valueOf(waypoints.getRallySeconds()),
                "x", String.valueOf(loc.getBlockX()),
                "y", String.valueOf(loc.getBlockY()),
                "z", String.valueOf(loc.getBlockZ()),
                "world", loc.getWorld() == null ? "" : loc.getWorld().getName()
        };

        send(player, "rally-started", data);
        for (UUID uuid : clan.getMembers()) {
            if (uuid.equals(player.getUniqueId())) continue;
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                send(member, "rally-notify", data);
            }
        }
    }

    private void setSpawn(CommandSender sender, String[] args) {
        if (!sender.hasPermission("thisclans.admin")) {
            send(sender, "no-permission");
            return;
        }
        if (args.length < 4) {
            send(sender, "usage-setspawn");
            return;
        }

        double x;
        double y;
        double z;
        try {
            x = Double.parseDouble(args[1]);
            y = Double.parseDouble(args[2]);
            z = Double.parseDouble(args[3]);
        } catch (NumberFormatException e) {
            send(sender, "coords-not-numbers");
            return;
        }

        final double limit = 30_000_000D;
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)
                || Math.abs(x) > limit || Math.abs(y) > 1_000_000D || Math.abs(z) > limit) {
            send(sender, "coords-out-of-range");
            return;
        }

        String world;
        if (sender instanceof Player player) {
            world = player.getWorld().getName();
        } else {
            world = plugin.getConfig().getString("spawn.world", "world");
        }

        plugin.getConfig().set("spawn.world", world);
        plugin.getConfig().set("spawn.x", x);
        plugin.getConfig().set("spawn.y", y);
        plugin.getConfig().set("spawn.z", z);
        plugin.saveConfig();

        for (Player online : Bukkit.getOnlinePlayers()) {
            waypoints.sendSpawn(online);
        }
        send(sender, "spawn-updated");
    }

    private void reload(CommandSender sender) {
        if (!sender.hasPermission("thisclans.admin")) {
            send(sender, "no-permission");
            return;
        }
        plugin.reloadAll();
        send(sender, "reloaded");
    }

    private UUID findMemberByName(Clan clan, String name) {
        for (UUID uuid : clan.getMembers()) {
            String memberName = Bukkit.getOfflinePlayer(uuid).getName();
            if (memberName != null && memberName.equalsIgnoreCase(name)) {
                return uuid;
            }
        }
        return null;
    }

    private void help(CommandSender sender) {
        plugin.getMessages().sendLines(sender, "help");
        if (sender.hasPermission("thisclans.admin")) {
            plugin.getMessages().sendLines(sender, "help-admin");
        }
    }

    @Override
    public List<String> onTabComplete(
            CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> values = new ArrayList<>(List.of(
                    "create", "invite", "accept", "kick", "leave", "disband",
                    "sethome", "home", "rally"
            ));
            if (sender.hasPermission("thisclans.admin")) {
                values.add("setspawn");
                values.add("reload");
            }
            return values.stream()
                    .filter(v -> v.startsWith(args[0].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("invite")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("kick")
                && sender instanceof Player player) {
            Clan clan = clans.getClan(player.getUniqueId());
            if (clan == null) return List.of();
            List<String> names = new ArrayList<>();
            for (UUID uuid : clan.getMembers()) {
                String name = Bukkit.getOfflinePlayer(uuid).getName();
                if (name != null && !uuid.equals(clan.getOwner())
                        && name.toLowerCase().startsWith(args[1].toLowerCase())) {
                    names.add(name);
                }
            }
            return names;
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("disband")
                && "confirm".startsWith(args[1].toLowerCase())) {
            return List.of("confirm");
        }

        return List.of();
    }
}
