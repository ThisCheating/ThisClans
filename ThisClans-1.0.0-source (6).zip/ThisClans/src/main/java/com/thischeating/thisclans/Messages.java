package com.thischeating.thisclans;

import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Textos editables desde plugins/ThisClans/messages.yml.
 * Si falta una clave en el archivo del servidor, usa el valor por defecto del plugin.
 * Placeholders: {player}, {clan}, {seconds}, etc. Colores con &amp;.
 */
public final class Messages {
    private final ThisClans plugin;
    private YamlConfiguration user;
    private YamlConfiguration defaults;

    public Messages(ThisClans plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        user = YamlConfiguration.loadConfiguration(file);

        InputStream in = plugin.getResource("messages.yml");
        if (in == null) {
            defaults = new YamlConfiguration();
        } else {
            defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(in, StandardCharsets.UTF_8));
        }
    }

    private String raw(String key) {
        String value = user.getString(key);
        if (value == null) {
            value = defaults.getString(key);
        }
        return value;
    }

    public String color(String text) {
        return text.replaceAll("&([0-9a-fk-orA-FK-OR])", "§$1");
    }

    private String fill(String template, String... pairs) {
        String result = template;
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            result = result.replace("{" + pairs[i] + "}", pairs[i + 1]);
        }
        return result;
    }

    /** Texto con colores y placeholders, sin prefijo. */
    public String get(String key, String... pairs) {
        String value = raw(key);
        if (value == null) return "§c[falta: " + key + "]";
        return fill(color(value), pairs);
    }

    /** Texto plano (sin colores), para nombres de waypoints. */
    public String plain(String key, String... pairs) {
        String value = raw(key);
        if (value == null) return key;
        return fill(value, pairs);
    }

    public String prefix() {
        String value = raw("prefix");
        return value == null ? "" : color(value);
    }

    /** Envia un mensaje con el prefijo al inicio. */
    public void send(CommandSender to, String key, String... pairs) {
        to.sendMessage(prefix() + get(key, pairs));
    }

    /** Envia una lista de lineas (sin prefijo), por ejemplo la ayuda. */
    public void sendLines(CommandSender to, String key, String... pairs) {
        List<String> lines = user.getStringList(key);
        if (lines == null || lines.isEmpty()) {
            lines = defaults.getStringList(key);
        }
        if (lines == null) return;
        for (String line : lines) {
            to.sendMessage(fill(color(line), pairs));
        }
    }
}
