package com.thischeating.thisclans;

import org.bukkit.plugin.java.JavaPlugin;

public final class ThisClans extends JavaPlugin {

    private ClanManager clanManager;
    private WaypointManager waypointManager;
    private Messages messages;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);

        clanManager = new ClanManager(this);
        clanManager.load();

        waypointManager = new WaypointManager(this);

        ClanCommand command = new ClanCommand(this, clanManager, waypointManager);
        if (getCommand("clan") != null) {
            getCommand("clan").setExecutor(command);
            getCommand("clan").setTabCompleter(command);
        }

        getServer().getPluginManager().registerEvents(
                new PlayerListener(this, waypointManager), this);

        new ThisClansApolloListener(this, waypointManager);

        long minutes = Math.max(1L, getConfig().getLong("settings.autosave-minutes", 5L));
        long ticks = minutes * 60L * 20L;

        getServer().getScheduler().runTaskTimer(
                this,
                clanManager::save,
                ticks,
                ticks
        );

        getLogger().info("ThisClans enabled.");
    }

    @Override
    public void onDisable() {
        if (waypointManager != null) {
            waypointManager.shutdown();
        }
        if (clanManager != null) {
            clanManager.save();
        }
    }

    public ClanManager getClanManager() {
        return clanManager;
    }

    public WaypointManager getWaypointManager() {
        return waypointManager;
    }

    public Messages getMessages() {
        return messages;
    }

    /** Recarga config.yml y messages.yml. */
    public void reloadAll() {
        reloadConfig();
        messages.reload();
    }
}
