package com.thischeating.thisclans;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class ClanManager {
    private final ThisClans plugin;
    private final Map<String, Clan> clans = new HashMap<>();
    private final Map<UUID, String> playerClans = new HashMap<>();
    private final File file;
    private YamlConfiguration data;

    public ClanManager(ThisClans plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "clans.yml");
    }

    public void load() {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create clans.yml: " + e.getMessage());
            }
        }

        data = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = data.getConfigurationSection("clans");
        if (root == null) return;

        for (String id : root.getKeys(false)) {
            String path = "clans." + id;
            String name = data.getString(path + ".name");
            String ownerRaw = data.getString(path + ".owner");
            if (name == null || ownerRaw == null) continue;

            UUID owner;
            try {
                owner = UUID.fromString(ownerRaw);
            } catch (IllegalArgumentException e) {
                continue;
            }

            Clan clan = new Clan(name, owner);
            List<String> members = data.getStringList(path + ".members");

            for (String raw : members) {
                try {
                    UUID uuid = UUID.fromString(raw);
                    clan.addMember(uuid);
                    playerClans.put(uuid, id);
                } catch (IllegalArgumentException ignored) {}
            }

            String worldName = data.getString(path + ".home.world");
            if (worldName != null) {
                World world = Bukkit.getWorld(worldName);
                if (world != null) {
                    clan.setHome(new Location(
                            world,
                            data.getDouble(path + ".home.x"),
                            data.getDouble(path + ".home.y"),
                            data.getDouble(path + ".home.z"),
                            (float) data.getDouble(path + ".home.yaw"),
                            (float) data.getDouble(path + ".home.pitch")
                    ));
                }
            }

            clans.put(id, clan);
            playerClans.putIfAbsent(owner, id);
        }
    }

    public void save() {
        if (data == null) data = new YamlConfiguration();
        data.set("clans", null);

        for (Map.Entry<String, Clan> entry : clans.entrySet()) {
            String path = "clans." + entry.getKey();
            Clan clan = entry.getValue();

            data.set(path + ".name", clan.getName());
            data.set(path + ".owner", clan.getOwner().toString());
            data.set(path + ".members",
                    clan.getMembers().stream().map(UUID::toString).toList());

            Location home = clan.getHome();
            if (home != null && home.getWorld() != null) {
                data.set(path + ".home.world", home.getWorld().getName());
                data.set(path + ".home.x", home.getX());
                data.set(path + ".home.y", home.getY());
                data.set(path + ".home.z", home.getZ());
                data.set(path + ".home.yaw", home.getYaw());
                data.set(path + ".home.pitch", home.getPitch());
            }
        }

        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save clans.yml: " + e.getMessage());
        }
    }

    public boolean createClan(String name, UUID owner) {
        String id = name.toLowerCase(Locale.ROOT);
        if (clans.containsKey(id) || playerClans.containsKey(owner)) return false;

        Clan clan = new Clan(name, owner);
        clans.put(id, clan);
        playerClans.put(owner, id);
        save();
        return true;
    }

    public Clan getClan(String name) {
        return name == null ? null : clans.get(name.toLowerCase(Locale.ROOT));
    }

    public Clan getClan(UUID player) {
        String id = playerClans.get(player);
        return id == null ? null : clans.get(id);
    }

    public boolean hasClan(UUID player) {
        return playerClans.containsKey(player);
    }

    public boolean addMember(Clan clan, UUID player) {
        if (playerClans.containsKey(player)) return false;
        clan.addMember(player);
        playerClans.put(player, clan.getName().toLowerCase(Locale.ROOT));
        save();
        return true;
    }

    public boolean removeMember(Clan clan, UUID player) {
        if (!clan.isMember(player) || clan.getOwner().equals(player)) return false;
        clan.removeMember(player);
        playerClans.remove(player);
        save();
        return true;
    }
}
