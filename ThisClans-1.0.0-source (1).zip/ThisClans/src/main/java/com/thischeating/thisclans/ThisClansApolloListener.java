package com.thischeating.thisclans;

import com.lunarclient.apollo.event.ApolloListener;
import com.lunarclient.apollo.event.EventBus;
import com.lunarclient.apollo.event.Listen;
import com.lunarclient.apollo.event.player.ApolloRegisterPlayerEvent;
import com.lunarclient.apollo.event.player.ApolloUnregisterPlayerEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class ThisClansApolloListener implements ApolloListener {
    private final WaypointManager waypointManager;

    public ThisClansApolloListener(ThisClans plugin, WaypointManager waypointManager) {
        this.waypointManager = waypointManager;
        EventBus.getBus().register(this);
    }

    @Listen
    public void onRegister(ApolloRegisterPlayerEvent event) {
        Player player = Bukkit.getPlayer(event.getPlayer().getUniqueId());
        if (player != null) {
            waypointManager.refreshPlayer(player);
        }
    }

    @Listen
    public void onUnregister(ApolloUnregisterPlayerEvent event) {
        Player player = Bukkit.getPlayer(event.getPlayer().getUniqueId());
        if (player != null) {
            waypointManager.clear(player);
        }
    }
}
