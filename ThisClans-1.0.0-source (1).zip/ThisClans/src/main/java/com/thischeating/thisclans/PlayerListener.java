package com.thischeating.thisclans;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {
    private final WaypointManager waypointManager;

    public PlayerListener(ThisClans plugin, WaypointManager waypointManager) {
        this.waypointManager = waypointManager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        waypointManager.clear(event.getPlayer());
    }
}
