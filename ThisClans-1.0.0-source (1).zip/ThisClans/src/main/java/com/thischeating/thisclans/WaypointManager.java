package com.thischeating.thisclans;

import com.lunarclient.apollo.Apollo;
import com.lunarclient.apollo.common.location.ApolloBlockLocation;
import com.lunarclient.apollo.module.waypoint.Waypoint;
import com.lunarclient.apollo.module.waypoint.WaypointModule;
import com.lunarclient.apollo.player.ApolloPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class WaypointManager {
    public static final String SPAWN_ID = "Spawn";
    public static final String HOME_ID = "Clan Base";
    public static final String RALLY_ID = "Clan Rally";

    private final ThisClans plugin;
    private final WaypointModule waypointModule;
    private final Map<UUID, BukkitTask> rallyTasks = new HashMap<>();

    public WaypointManager(ThisClans plugin) {
        this.plugin = plugin;
        this.waypointModule =
                Apollo.getModuleManager().getModule(WaypointModule.class);
    }

    public void sendSpawn(Player player) {
        Location location = getSpawnLocation();
        if (location != null) {
            display(player, SPAWN_ID, "Spawn", location, Color.GREEN, false);
        }
    }

    public void sendHome(Player player) {
        Clan clan = plugin.getClanManager().getClan(player.getUniqueId());
        if (clan == null || clan.getHome() == null) {
            remove(player, HOME_ID);
            return;
        }
        display(player, HOME_ID, "Clan Base", clan.getHome(), Color.CYAN, false);
    }

    public void sendRally(Player source) {
        Clan clan = plugin.getClanManager().getClan(source.getUniqueId());
        if (clan == null) return;

        Location location = source.getLocation().clone();
        cancelRally(source.getUniqueId());

        for (UUID uuid : clan.getMembers()) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                display(member, RALLY_ID, "Clan Rally", location, Color.ORANGE, true);
            }
        }

        long seconds = Math.max(1L,
                plugin.getConfig().getLong("settings.rally-duration-seconds", 60L));

        BukkitTask task = Bukkit.getScheduler().runTaskLater(
                plugin,
                () -> {
                    for (UUID uuid : clan.getMembers()) {
                        Player member = Bukkit.getPlayer(uuid);
                        if (member != null && member.isOnline()) {
                            remove(member, RALLY_ID);
                        }
                    }
                    rallyTasks.remove(source.getUniqueId());
                },
                seconds * 20L
        );

        rallyTasks.put(source.getUniqueId(), task);
    }

    public void refreshPlayer(Player player) {
        sendSpawn(player);
        sendHome(player);
    }

    public void clear(Player player) {
        remove(player, SPAWN_ID);
        remove(player, HOME_ID);
        remove(player, RALLY_ID);
    }

    public void removeHome(Player player) {
        remove(player, HOME_ID);
    }

    private void cancelRally(UUID uuid) {
        BukkitTask old = rallyTasks.remove(uuid);
        if (old != null) old.cancel();
    }

    private void display(
            Player player,
            String id,
            String name,
            Location location,
            Color color,
            boolean temporary
    ) {
        Optional<ApolloPlayer> apolloPlayer =
                Apollo.getPlayerManager().getPlayer(player.getUniqueId());

        if (apolloPlayer.isEmpty()) return;

        if (location.getWorld() == null) return;

        ApolloBlockLocation blockLocation = ApolloBlockLocation.builder()
                .world(location.getWorld().getName())
                .x(location.getBlockX())
                .y(location.getBlockY())
                .z(location.getBlockZ())
                .build();

        Waypoint waypoint = Waypoint.builder()
                .name(id)
                .location(blockLocation)
                .color(color)
                .preventRemoval(false)
                .hidden(false)
                .build();

        waypointModule.displayWaypoint(apolloPlayer.get(), waypoint);
    }

    private void remove(Player player, String id) {
        Optional<ApolloPlayer> apolloPlayer =
                Apollo.getPlayerManager().getPlayer(player.getUniqueId());

        apolloPlayer.ifPresent(p -> waypointModule.removeWaypoint(p, id));
    }

    private Location getSpawnLocation() {
        String worldName = plugin.getConfig().getString("spawn.world");
        if (worldName == null) return null;

        org.bukkit.World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        return new Location(
                world,
                plugin.getConfig().getDouble("spawn.x"),
                plugin.getConfig().getDouble("spawn.y"),
                plugin.getConfig().getDouble("spawn.z")
        );
    }
}
