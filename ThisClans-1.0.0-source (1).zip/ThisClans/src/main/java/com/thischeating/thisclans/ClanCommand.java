package com.thischeating.thisclans;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public final class ClanCommand implements CommandExecutor, TabCompleter {
    private final ThisClans plugin;
    private final ClanManager clans;
    private final WaypointManager waypoints;

    public ClanCommand(ThisClans plugin, ClanManager clans, WaypointManager waypoints) {
        this.plugin = plugin;
        this.clans = clans;
        this.waypoints = waypoints;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> create(sender, args);
            case "invite" -> invite(sender, args);
            case "accept" -> accept(sender);
            case "kick" -> kick(sender, args);
            case "sethome" -> setHome(sender);
            case "home" -> home(sender);
            case "rally" -> rally(sender);
            case "setspawn" -> setSpawn(sender, args);
            default -> help(sender);
        }
        return true;
    }

    private void create(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 2) {
            player.sendMessage("§c/clan create <nombre>");
            return;
        }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_]{3,16}")) {
            player.sendMessage("§cNombre inválido. Usa 3-16 caracteres: A-Z, 0-9 o _.");
            return;
        }
        if (clans.createClan(name, player.getUniqueId())) {
            player.sendMessage("§aClan creado: §f" + name);
        } else {
            player.sendMessage("§cEse nombre ya existe o ya tienes un clan.");
        }
    }

    private void invite(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            player.sendMessage("§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            player.sendMessage("§cSolo el líder puede invitar.");
            return;
        }
        if (args.length < 2) {
            player.sendMessage("§c/clan invite <jugador>");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage("§cJugador no encontrado.");
            return;
        }
        if (clans.hasClan(target.getUniqueId())) {
            player.sendMessage("§cEse jugador ya tiene clan.");
            return;
        }

        PendingInvite.put(target.getUniqueId(), clan.getName());
        player.sendMessage("§aInvitación enviada a §f" + target.getName());
        target.sendMessage("§eHas sido invitado al clan §f" + clan.getName() + "§e.");
        target.sendMessage("§7Usa §f/clan accept §7para aceptar.");
    }

    private void accept(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        if (clans.hasClan(player.getUniqueId())) {
            player.sendMessage("§cYa tienes clan.");
            return;
        }

        String clanName = PendingInvite.get(player.getUniqueId());
        if (clanName == null) {
            player.sendMessage("§cNo tienes invitaciones pendientes.");
            return;
        }

        Clan clan = clans.getClan(clanName);
        if (clan == null) {
            PendingInvite.remove(player.getUniqueId());
            player.sendMessage("§cEse clan ya no existe.");
            return;
        }

        if (clans.addMember(clan, player.getUniqueId())) {
            PendingInvite.remove(player.getUniqueId());
            player.sendMessage("§aTe uniste a §f" + clan.getName() + "§a.");
            waypoints.sendHome(player);
        }
    }

    private void kick(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            player.sendMessage("§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            player.sendMessage("§cSolo el líder puede expulsar.");
            return;
        }
        if (args.length < 2) {
            player.sendMessage("§c/clan kick <jugador>");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null || !clan.isMember(target.getUniqueId())) {
            player.sendMessage("§cEse jugador no pertenece al clan.");
            return;
        }

        if (clans.removeMember(clan, target.getUniqueId())) {
            target.sendMessage("§cHas sido expulsado del clan.");
            waypoints.removeHome(target);
            player.sendMessage("§aJugador expulsado.");
        }
    }

    private void setHome(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());
        if (clan == null) {
            player.sendMessage("§cNo tienes clan.");
            return;
        }
        if (!clan.getOwner().equals(player.getUniqueId())) {
            player.sendMessage("§cSolo el líder puede cambiar la base.");
            return;
        }

        Location home = player.getLocation().clone();
        clan.setHome(home);
        clans.save();

        for (var uuid : clan.getMembers()) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) {
                waypoints.sendHome(member);
            }
        }
        player.sendMessage("§aBase del clan actualizada.");
    }

    private void home(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        Clan clan = clans.getClan(player.getUniqueId());

        if (clan == null || clan.getHome() == null) {
            player.sendMessage("§cTu clan no tiene base.");
            return;
        }

        player.teleportAsync(clan.getHome());
        player.sendMessage("§aTeletransportándote a la base...");
    }

    private void rally(CommandSender sender) {
        if (!(sender instanceof Player player)) return;
        if (clans.getClan(player.getUniqueId()) == null) {
            player.sendMessage("§cNo tienes clan.");
            return;
        }

        waypoints.sendRally(player);
        long seconds = Math.max(1L,
                plugin.getConfig().getLong("settings.rally-duration-seconds", 60L));
        player.sendMessage("§6Rally activado durante §f" + seconds + " segundos§6.");
    }

    private void setSpawn(CommandSender sender, String[] args) {
        if (!sender.hasPermission("thisclans.admin")) {
            sender.sendMessage("§cSin permisos.");
            return;
        }
        if (args.length < 4) {
            sender.sendMessage("§c/clan setspawn <x> <y> <z>");
            return;
        }

        try {
            double x = Double.parseDouble(args[1]);
            double y = Double.parseDouble(args[2]);
            double z = Double.parseDouble(args[3]);

            String world;
            if (sender instanceof Player player) {
                world = player.getWorld().getName();
            } else {
                world = plugin.getConfig().getString("spawn.world", "world");
            }

            plugin.getConfig().set("spawn.world", world);
            plugin.getConfig().set("spawn.x", x);
            plugin.getConfig().set("spawn.y", y);
            plugin.getConfig().set("spawn.z", z);
            plugin.saveConfig();

            for (Player player : Bukkit.getOnlinePlayers()) {
                waypoints.sendSpawn(player);
            }
            sender.sendMessage("§aWaypoint global de Spawn actualizado.");
        } catch (NumberFormatException e) {
            sender.sendMessage("§cLas coordenadas deben ser números.");
        }
    }

    private void help(CommandSender sender) {
        sender.sendMessage("§6§lThisClans");
        sender.sendMessage("§e/clan create <nombre>");
        sender.sendMessage("§e/clan invite <jugador>");
        sender.sendMessage("§e/clan accept");
        sender.sendMessage("§e/clan kick <jugador>");
        sender.sendMessage("§e/clan sethome");
        sender.sendMessage("§e/clan home");
        sender.sendMessage("§e/clan rally");
        if (sender.hasPermission("thisclans.admin")) {
            sender.sendMessage("§e/clan setspawn <x> <y> <z>");
        }
    }

    @Override
    public List<String> onTabComplete(
            CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> values = Arrays.asList(
                    "create", "invite", "accept", "kick",
                    "sethome", "home", "rally"
            );
            if (sender.hasPermission("thisclans.admin")) {
                values = new java.util.ArrayList<>(values);
                values.add("setspawn");
            }
            return values.stream()
                    .filter(v -> v.startsWith(args[0].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 &&
                (args[0].equalsIgnoreCase("invite") ||
                 args[0].equalsIgnoreCase("kick"))) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .toList();
        }

        return List.of();
    }
}
