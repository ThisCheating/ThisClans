package com.thischeating.thisclans;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PendingInvite {
    private static final Map<UUID, String> INVITES = new ConcurrentHashMap<>();

    private PendingInvite() {}

    public static void put(UUID player, String clan) {
        INVITES.put(player, clan);
    }

    public static String get(UUID player) {
        return INVITES.get(player);
    }

    public static void remove(UUID player) {
        INVITES.remove(player);
    }
}
