package com.thischeating.thisclans;

import org.bukkit.Location;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Clan {
    private final String name;
    private final UUID owner;
    private final Set<UUID> members = new HashSet<>();
    private Location home;

    public Clan(String name, UUID owner) {
        this.name = name;
        this.owner = owner;
        members.add(owner);
    }

    public String getName() { return name; }
    public UUID getOwner() { return owner; }
    public Set<UUID> getMembers() { return members; }

    public boolean isMember(UUID uuid) {
        return members.contains(uuid);
    }

    public void addMember(UUID uuid) {
        members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public Location getHome() { return home; }
    public void setHome(Location home) { this.home = home; }
}
