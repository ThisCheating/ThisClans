# ThisClans

Plugin ligero de clanes para Paper 1.21.11 con integración de waypoints de Lunar Client Apollo.

## Dependencias del servidor

Instala Apollo externamente en el servidor.

ThisClans NO incluye Apollo dentro de su JAR.

## Compilar

Requisitos:
- Java 21
- Maven

Ejecuta:

```bash
mvn clean package
```

JAR generado:

```text
target/ThisClans-1.0.0.jar
```

Copia el JAR a:

```text
plugins/
```

y coloca Apollo externamente en `plugins/`.

## Comandos

/clan create <nombre>
/clan invite <jugador>
/clan accept
/clan kick <jugador>
/clan sethome
/clan home
/clan rally
/clan setspawn <x> <y> <z>

## Waypoints

- Spawn global para jugadores Lunar Client.
- Base del clan para miembros Lunar Client.
- Rally durante 60 segundos.
- /clan sethome actualiza el waypoint de los miembros conectados.

Los waypoints iniciales se envían en ApolloRegisterPlayerEvent, no en PlayerJoinEvent.

## Persistencia

Los clanes se guardan en plugins/ThisClans/clans.yml.
